//
//  CollectionViewCell.swift
//  CollectionViewinSwift
//
//  Created by Kaushal Elsewhere on 29/04/16.
//  Copyright © 2016 Elsewhere. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    lazy var imageView:UIImageView = UIImageView()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        self.imageView.frame = CGRect(x: 0, y: 0, width: frame.size.width, height: frame.size.height)
        self.addSubview(imageView)
        
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
