//
//  NextViewController.swift
//  CollectionViewinSwift
//
//  Created by Kaushal Elsewhere on 29/04/16.
//  Copyright © 2016 Elsewhere. All rights reserved.
//

import UIKit
extension NextViewController:RMPZoomTransitionDelegate{
    func transitionSourceImageView() ->UIImageView{
        let imageView = UIImageView(image: self.imageView.image)
        imageView.frame = self.imageView.convertRect(self.imageView.frame, toView: self.view)
        
        return imageView
    }
    func transitionSourceBackgroundColor() ->UIColor{
        return .whiteColor()
    }
    func transitionDestinationImageViewFrame() ->CGRect{
        self.view.layoutIfNeeded()
        return self.imageView.frame
    }
    
    func zoomTransitionAnimator(animator: RMPZoomTransitionAnimator!, didCompleteTransition didComplete: Bool, animatingSourceImageView imageView: UIImageView!) {
        self.imageView.image = UIImage(named: "\(selectedIndexPath.row).jpg")
        
    }
}
class NextViewController: UIViewController,RMPZoomTransitionAnimating {
    var selectedIndexPath:NSIndexPath!
    
    @IBOutlet weak var imageView: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        setupUI()
    }
    func setupUI(){
        
    }

    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
