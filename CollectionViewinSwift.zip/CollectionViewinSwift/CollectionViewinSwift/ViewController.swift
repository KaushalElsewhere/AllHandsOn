//
//  ViewController.swift
//  CollectionViewinSwift
//
//  Created by Kaushal Elsewhere on 29/04/16.
//  Copyright © 2016 Elsewhere. All rights reserved.
//

import UIKit
extension ViewController: RMPZoomTransitionAnimating, RMPZoomTransitionDelegate{
//    func imageViewFrame() -> CGRect {
//        if let collectionView = self.collectionView,
//            let indexPath = self.selectedIndexPath,
//            let cell = collectionView.cellForItemAtIndexPath(indexPath) as? NewsCollectionViewCell,
//            let imageView = cell.fgImageView {
//            let frame = imageView.convertRect(imageView.frame, toView: self.view.window)
//            return frame
//        }
//        return CGRectZero
//    }
    func imageViewFrameInWindow() -> CGRect {
        let indexPath = self.collectionView.indexPathsForSelectedItems()?.first
        let cell:CollectionViewCell = self.collectionView.cellForItemAtIndexPath(indexPath!) as! CollectionViewCell
        let frame = cell.imageView.convertRect(cell.imageView.frame, toView: self.collectionView.superview)
        
        return frame
    }
    func transitionSourceImageView() -> UIImageView{
        let imageView = UIImageView(frame: imageViewFrameInWindow())
        let indexPath = self.collectionView.indexPathsForSelectedItems()?.first
        let cell = self.collectionView.cellForItemAtIndexPath(indexPath!) as! CollectionViewCell
        imageView.image = cell.imageView.image
        return imageView
    }
    func transitionSourceBackgroundColor() -> UIColor{
        return .whiteColor()
    }
    func transitionDestinationImageViewFrame() ->CGRect{
        
        return imageViewFrameInWindow()
    }
}
extension ViewController: UINavigationControllerDelegate {
    func navigationController(navigationController: UINavigationController, animationControllerForOperation operation: UINavigationControllerOperation, fromViewController fromVC: UIViewController, toViewController toVC: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        
        
        if fromVC is RMPZoomTransitionAnimating && toVC is RMPZoomTransitionAnimating {
            let animator = RMPZoomTransitionAnimator()
            animator.goingForward = (operation == .Push)
            animator.sourceTransition = fromVC as? protocol<RMPZoomTransitionAnimating, RMPZoomTransitionDelegate>
            animator.destinationTransition = toVC as? protocol<RMPZoomTransitionAnimating, RMPZoomTransitionDelegate>
            return animator
        } else {
            return nil
        }
    }
    
}
extension ViewController{
    func collectionView(collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 8
    }
    
    func numberOfSectionsInCollectionView(collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(collectionView: UICollectionView, cellForItemAtIndexPath indexPath: NSIndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCellWithReuseIdentifier("cell", forIndexPath: indexPath) as! CollectionViewCell
        
        //cell.imageView.frame = CGRect(x: 0, y: 0, width: layout.itemSize.width, height: layout.itemSize.height)
        cell.imageView.image = UIImage(named:"\(indexPath.row).jpg")
        
        return cell
    }
    
    func collectionView(collectionView: UICollectionView, didSelectItemAtIndexPath indexPath: NSIndexPath) {
        let next = self.storyboard?.instantiateViewControllerWithIdentifier("NEXT") as! NextViewController
        next.selectedIndexPath = indexPath
        self.navigationController?.pushViewController(next, animated: true)
    }
}

class ViewController: UIViewController,UICollectionViewDelegate, UICollectionViewDataSource {

    var collectionView: UICollectionView!
    
    lazy var layout: UICollectionViewFlowLayout = UICollectionViewFlowLayout()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        setupUI()
        
        
        self.navigationController?.delegate = self
        
    }
    
    func setupUI(){
        
        layout.sectionInset = UIEdgeInsets(top: 5, left: 5, bottom: 5, right: 5)
        layout.itemSize = CGSize(width:self.view.bounds.width/2-10, height:self.view.bounds.width/2-10)
        
        self.collectionView = UICollectionView(frame: self.view.frame, collectionViewLayout: layout)
        self.collectionView.registerClass(CollectionViewCell.self, forCellWithReuseIdentifier: "cell")
        //self.collectionView.collectionViewLayout = layout
        self.collectionView.backgroundColor = UIColor.whiteColor()
        self.collectionView.delegate = self
        self.collectionView.dataSource = self
        self.view.addSubview(self.collectionView)
        //self.view.setNeedsLayout()
    }
}


